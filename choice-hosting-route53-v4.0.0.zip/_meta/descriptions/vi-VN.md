Phần mở rộng này tích hợp Plesk với Amazon Route 53, một dịch vụ web DNS có thể mở rộng và rất sẵn có để bạn có thể sử dụng như một dịch vụ DNS bên ngoài cho miền của mình. Phần mở rộng tự động đồng bộ các khu vực DNS giữa Plesk và Amazon Route 53. Bạn có thể:

- Xem danh sách các máy chủ tên Amazon được sử dụng để lưu trữ các vùng DNS của bạn và địa chỉ IP của chúng.
- Quản lý bộ phái đoàn của máy chủ định danh cho các vùng DNS đã đăng ký.
- Đồng bộ hóa tất cả các thông tin vùng DNS giữa máy chủ định danh của Plesk và Amazon.
- Xóa tất cả các thông tin vùng DNS khỏi máy chủ định danh của Amazon.

[Read more](https://www.plesk.com/blog/business-industry/white-label-dns-with-amazon-route53) giới thiệu cách sử dụng Amazon Route 53.

**Ghi chú:** Để sử dụng phần mở rộng này, bạn cần có tài khoản tại [portal.aws.amazon.com](https://portal.aws.amazon.com/).