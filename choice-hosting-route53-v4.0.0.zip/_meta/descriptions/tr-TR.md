Bu uzantı, alan adlarınız için harici bir DNS servisi olarak kullanabileceğiniz, çok kullanılabilir ve ölçeklenebilir bir DNS web servisi olan Plesk'i Amazon Route 53 ile entegre eder. Uzantı, Plesk ile Amazon Route 53 arasındaki DNS bölgelerini otomatik olarak senkronize eder. Aşağıdakileri yapabilirsiniz: 

- DNS bölgelerinizle onların IP adreslerini barındırmak için kullanılan Amazon ad sunucularının listesine bakabilirsiniz. 
- Kayıtlı DNS bölgeleri için ad sunucularının atama setlerini yönetebilirsiniz. 
- Plesk ile Amazon ad sunucuları arasındaki bütün DNS bölgeleri bilgilerini senkronize edebilirsiniz. 
- Bütün DNS bölgeleri bilgilerini Amazon ad sunucularından kaldırabilirsiniz. 

Amazon Route 53 kullanma hakkında [daha fazlasını okuyun](https://www.plesk.com/blog/business-industry/white-label-dns-with-amazon-route53). 

**Not:** Bu uzantıyı kullanmak için, [portal.aws.amazon.com](https://portal.aws.amazon.com/) adresinde bir hesabınızın olması gerekir.