Ini-integrate ng extension na ito ang Plesk sa Amazon Route 53, isang madaling makuha at madaling masukat na DNS web service na magagamit mo bilang external na DNS service para sa mga domain mo. Awtomatikong sini-synchronize ng extension ang mga DNS zone sa pagitan ng Plesk at Amazon Route 53. Maaari kang:

- Tingnan ang listahan ng mga server ng pangalan ng Amazon na ginamit upang i-host ang iyong mga DNS zone at ang kanilang mga IP address.
- Pamahalaan ang mga set ng delegasyon ng mga server ng pangalan para sa mga rehistradong DNS zone.
- I-synchronize ang lahat ng impormasyon ng zone ng DNS sa pagitan ng mga server ng Plesk at Amazon.
- Alisin ang lahat ng impormasyon ng zone ng DNS mula sa mga server ng pangalan ng Amazon.

[Read more](https://www.plesk.com/blog/business-industry/white-label-dns-with-amazon-route53) tungkol sa paggamit ng Amazon Route 53.

**Tandaan:** Upang magamit ang extension na ito, kailangan mong magkaroon ng account sa [portal.aws.amazon.com](https://portal.aws.amazon.com/).