<?php
// Copyright 1999-2018. Plesk International GmbH.
pm_Context::init('route53');

$application = new pm_Application();
$application->run();
